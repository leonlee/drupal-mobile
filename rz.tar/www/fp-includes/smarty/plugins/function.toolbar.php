<?php
/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.toolbar.php
 * Type:     function
 * Name:     editortop
 * Purpose:  outputs a random magic answer
 * -------------------------------------------------------------
 */
function smarty_function_toolbar($params, &$smarty)
{
    do_action('editor_toolbar');
}
?> 
