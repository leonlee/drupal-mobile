<?php

$fp_widgets = array (
  'right' => 
  array (
    0 => 'searchbox',
    1 => 'lastentries',
    2 => 'categories',
    3 => 'archives',
  ),
  'menubar' => 
  array (
    0 => 'blockparser:menu',
  ),
);

?>