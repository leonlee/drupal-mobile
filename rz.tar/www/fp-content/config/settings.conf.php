<?php

$fp_config = array (
  'general' => 
  array (
    'www' => 'http://www.riderzen.com/',
    'title' => 'Rider Zen',
    'subtitle' => '独立 自由 挑战',
    'footer' => '在路上...',
    'author' => 'Leon Lee',
    'email' => 'mail.lgq@gmail.com',
    'startpage' => NULL,
    'maxentries' => '5',
    'notify' => true,
    'theme' => 'deckay40',
    'blogid' => 'fp-e11fbdda',
    'charset' => 'utf-8',
    'style' => 'deckay-red',
  ),
  'locale' => 
  array (
    'timeoffset' => '2',
    'timeformat' => '%H:%M:%S',
    'dateformat' => '%A, %B %e, %Y',
    'dateformatshort' => '%Y-%m-%d',
    'charset' => 'utf-8',
    'lang' => 'en-us',
  ),
  'plugins' => 
  array (
    'blockparser' => 
    array (
      'pages' => 
      array (
        0 => 'menu',
        1 => 'about',
      ),
    ),
    'bbcode' => 
    array (
      'escape-html' => false,
      'comments' => false,
      'editor' => true,
      'url-maxlen' => 40,
    ),
  ),
);

?>