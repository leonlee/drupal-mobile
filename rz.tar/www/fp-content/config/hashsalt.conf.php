<?php

$fp_hashsalt = 'fp-e11fbdda/var/www/http://www.riderzen.com/840380924';

?>