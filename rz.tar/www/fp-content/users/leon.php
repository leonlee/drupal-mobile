<?php

$user = array (
  'userid' => 'leon',
  'password' => 'eef7d2c86124133238c7cac313b061e9',
  'www' => 'http://www.riderzen.com/',
  'email' => 'mail.lgq@gmail.com',
);

?>