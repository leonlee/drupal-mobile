<?php /* Smarty version 2.6.26, created on 2012-05-01 02:09:10
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'tag', 'header.tpl', 4, false),array('function', 'action', 'header.tpl', 6, false),array('block', 'widgets', 'header.tpl', 22, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo ((is_array($_tmp=$this->_tpl_vars['flatpress']['title'])) ? $this->_run_mod_handler('tag', true, $_tmp, 'wp_title', '&raquo;') : theme_apply_filters_wrapper($_tmp, 'wp_title', '&raquo;')); ?>
</title>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $this->_tpl_vars['flatpress']['charset']; ?>
" />
	<?php echo theme_smarty_function_action(array('hook' => 'wp_head'), $this);?>

</head>

<body>
<div id="container">
	
	<div id="header">
	
		<h1><a href="<?php echo $this->_tpl_vars['flatpress']['www']; ?>
"><?php echo $this->_tpl_vars['flatpress']['title']; ?>
</a></h1>
		<h2><?php echo $this->_tpl_vars['flatpress']['subtitle']; ?>
</h2>
		
	</div><!-- end header -->
	
	
	<div id="menu">
	
		<?php $this->_tag_stack[] = array('widgets', array('pos' => 'menubar')); $_block_repeat=true;smarty_block_widgets($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>	
			<?php echo $this->_tpl_vars['content']; ?>

		<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_widgets($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
		
	</div><!-- end menu -->