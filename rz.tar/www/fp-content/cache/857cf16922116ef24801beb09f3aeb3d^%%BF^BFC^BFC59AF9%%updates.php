<?php /* Smarty version 2.6.26, created on 2012-05-01 03:13:57
         compiled from admin:maintain/updates */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'sprintf', 'admin:maintain/updates', 3, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['panelstrings']['head']; ?>
</h2>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "shared:errorlist.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php echo ((is_array($_tmp=$this->_tpl_vars['panelstrings']['list'])) ? $this->_run_mod_handler('sprintf', true, $_tmp, @SYSTEM_VER, $this->_tpl_vars['sfweb'], $this->_tpl_vars['updates']['stable'], $this->_tpl_vars['fpweb'], $this->_tpl_vars['updates']['unstable']) : sprintf($_tmp, @SYSTEM_VER, $this->_tpl_vars['sfweb'], $this->_tpl_vars['updates']['stable'], $this->_tpl_vars['fpweb'], $this->_tpl_vars['updates']['unstable'])); ?>

<?php if ($this->_tpl_vars['updates']['notice']): ?>
<h5><?php echo $this->_tpl_vars['panelstrings']['notice']; ?>
</h5>
<p><?php echo $this->_tpl_vars['updates']['notice']; ?>
</p>
<?php endif; ?>