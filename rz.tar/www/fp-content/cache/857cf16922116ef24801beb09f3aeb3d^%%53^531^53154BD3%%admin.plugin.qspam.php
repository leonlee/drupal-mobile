<?php /* Smarty version 2.6.26, created on 2012-05-01 03:06:48
         compiled from plugin:qspam/admin.plugin.qspam */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'html_form', 'plugin:qspam/admin.plugin.qspam', 5, false),array('modifier', 'wptexturize', 'plugin:qspam/admin.plugin.qspam', 8, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['plang']['head']; ?>
</h2>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "shared:errorlist.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php $this->_tag_stack[] = array('html_form', array('class' => "option-set")); $_block_repeat=true;smarty_block_html_form($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>

<div class="option-list">
<p><?php echo ((is_array($_tmp=$this->_tpl_vars['plang']['desc1'])) ? $this->_run_mod_handler('wptexturize', true, $_tmp) : wptexturize($_tmp)); ?>
</p>
<p>
	<textarea id="qs-wordlist" name="qs-wordlist" rows="10" cols="20"><?php echo $this->_tpl_vars['qscfg']['wordlist']; ?>
</textarea>
</p>
<p><?php echo $this->_tpl_vars['plang']['desc2']; ?>
</p>
</div>

<h2><?php echo $this->_tpl_vars['plang']['options']; ?>
</h2>
<dl class="option-list">
	<dt><label><?php echo $this->_tpl_vars['plang']['desc3']; ?>
</label></dt>
	<dd>
		<?php echo $this->_tpl_vars['plang']['desc3pre']; ?>

		<input type="text" class="smalltextinput" id="qs-number" name="qs-number" value="<?php echo $this->_tpl_vars['qscfg']['number']; ?>
" />
		<?php echo $this->_tpl_vars['plang']['desc3post']; ?>

	</dd>
	
</dl>

<div class="buttonbar">
	<input type="submit" value="<?php echo $this->_tpl_vars['plang']['submit']; ?>
"/>
</div>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_html_form($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>