<?php /* Smarty version 2.6.26, created on 2012-05-01 02:13:10
         compiled from entry-default.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'entry-default.tpl', 1, false),array('modifier', 'link', 'entry-default.tpl', 11, false),array('modifier', 'tag', 'entry-default.tpl', 13, false),)), $this); ?>
<div id="<?php echo $this->_tpl_vars['id']; ?>
" class="entry <?php echo ((is_array($_tmp=$this->_tpl_vars['date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "y-%Y m-%m d-%d") : theme_date_format($_tmp, "y-%Y m-%m d-%d")); ?>
 category-<?php echo $this->_tpl_vars['categories'][0]; ?>
">
	
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "shared:entryadminctrls.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	
	<div class="entry-title">
		<div class="calendario-titolo">
			<div class="mese"><?php echo ((is_array($_tmp=$this->_tpl_vars['date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%b") : theme_date_format($_tmp, "%b")); ?>
</div>
			<div class="giorno"><?php echo ((is_array($_tmp=$this->_tpl_vars['date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d") : theme_date_format($_tmp, "%d")); ?>
</div>
		</div>
		<div class="icomments">
			<a href="<?php echo ((is_array($_tmp=$this->_tpl_vars['id'])) ? $this->_run_mod_handler('link', true, $_tmp, 'comments_link') : theme_apply_filters_link_wrapper($_tmp, 'comments_link')); ?>
#comments"><?php echo $this->_tpl_vars['comments']; ?>
</a>
		</div>
		<a href="<?php echo ((is_array($_tmp=$this->_tpl_vars['id'])) ? $this->_run_mod_handler('link', true, $_tmp, 'post_link') : theme_apply_filters_link_wrapper($_tmp, 'post_link')); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['subject'])) ? $this->_run_mod_handler('tag', true, $_tmp, 'the_title') : theme_apply_filters_wrapper($_tmp, 'the_title')); ?>
</a>
	</div>
	<div class="entry-content">
		<?php echo ((is_array($_tmp=$this->_tpl_vars['content'])) ? $this->_run_mod_handler('tag', true, $_tmp, 'the_content') : theme_apply_filters_wrapper($_tmp, 'the_content')); ?>

	</div>
</div>