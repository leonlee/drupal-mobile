<?php /* Smarty version 2.6.26, created on 2012-05-01 02:12:57
         compiled from footer.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'action', 'footer.tpl', 4, false),)), $this); ?>
		</div><!-- end of #outer-container -->
		
		<div id="footer">
			<?php echo theme_smarty_function_action(array('hook' => 'wp_footer'), $this);?>

			<!--
				Even though your not required to do this, we'd appreciate
				a lot if you didn't remove the notice above.
				
				This way we'll get a better ranking on search engines
				and you'll spread the FlatPress word all around the world :)
				
				If you really want to remove it, you may want to
				consider doing at least a small donation.
			-->
			<p><a href="login.php">Login</a> | <a href="admin.php">Admin area</a></p>
			<p><a href="<?php echo $this->_tpl_vars['plmobilen']; ?>
">Versione desktop</a> | <a href="<?php echo $this->_tpl_vars['plmobiles']; ?>
">Disattiva la versione mobile</a></p>
			<p>This blog is powered by <a href="http://www.flatpress.org/">FlatPress</a>. Theme designed by <a href="http://lantaca.altervista.org/">Lantaca Ucasi</a></p>
		</div>
	</div><!-- end of #body-container -->

</body>
</html>