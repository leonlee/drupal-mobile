<?php
/*  
Style Name: Deckay Red
Style URI: http://zeuder.com.ar/descargas/
Description: Deckay in red colors
Version: 4.0
Author: zeuder
Author URI: http://zeuder.com.ar/
*/



	
	$style['name'] = 'deckay-red';
	$style['author'] = 'zeuder';
	$style['www'] = 'http://zeuder.com.ar/';
	
	$style['version'] = 4.0;
		
	$style['style_def'] = 'style.css';
	$style['style_admin'] = 'admin.css';
	$style['style_print'] = 'print.css';
	$style['style'] = 'default';
	
?>
