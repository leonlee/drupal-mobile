<?php
/*  
Style Name: Deckay Blue
Style URI: http://zeuder.com.ar/descargas/
Description: Deckay in blue colors
Version: 4.0
Author: zeuder
Author URI: http://zeuder.com.ar/
*/



	
	$style['name'] = 'deckay-blue';
	$style['author'] = 'zeuder';
	$style['www'] = 'http://zeuder.com.ar/';
	
	$style['version'] = 4.0;
		
	$style['style_def'] = 'style.css';
	$style['style_admin'] = 'admin.css';
	$style['style_print'] = 'print.css';
	$style['style'] = 'default';
	
?>
