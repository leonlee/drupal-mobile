<?php
/*  
Theme Name: Deckay 4.0
Theme URI: http://zeuder.com.ar/descargas/
Description: Fresh theme in 7 styles.
Version: 4.0
Author: zeuder
Author URI: http://zeuder.com.ar/
*/


	$theme['name'] = 'Deckay 4.0';
	$theme['author'] = 'zeuder';
	$theme['www'] = 'http://zeuder.com.ar/';
	$theme['description'] = 'Fresh theme in 7 styles';
	
	
	$theme['version'] = 4.0;
	$theme['style_def'] = 'style.css';
	$theme['style_admin'] = 'admin.css';
	$theme['default_style'] = 'deckay-black';
	
	// Other theme settings
	
		// overrides default tabmenu
		// and panel layout
	remove_filter('admin_head', 'admin_head_action');
	
		// register widgetsets
	register_widgetset('right');
	register_widgetset('left'); 
	register_widgetset('menubar');
	
?>
