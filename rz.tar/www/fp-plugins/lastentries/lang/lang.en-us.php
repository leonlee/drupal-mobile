<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Last ',
		'subject_after_count'	=> ' entries',
		'edit'			=> 'edit',
		'add_entry'		=> 'Add entry',
		'no_entries'	=> 'No entries'
	
	
	);

?>
