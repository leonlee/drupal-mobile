<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Admin area',
		'welcome'		=> 'Welcome home, ',
		'admin_panel'	=> 'Admin panel',
		'add_entry'		=> 'Add entry',
		'add_static'	=> 'Add static',
		'logout'		=> 'Logout'
	
	);

?>