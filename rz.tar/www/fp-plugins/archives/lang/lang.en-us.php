<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Archives',
		'no_posts'		=> 'No posts',
	
	);

?>
